<?php
$conn = mysqli_connect("localhost","root", "","credentials"); //required credentials to access the db

if($conn){
    //echo "DB Connected";
}
else{
    echo "DB connection failed";
}
?>