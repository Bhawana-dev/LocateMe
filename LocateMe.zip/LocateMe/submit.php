<?php
include "conn.php";                                                         //establishing DB connection

$msg = "";

if(isset($_POST['submit'])){                                                //getting data from form at onclick

    $full_name = "dummy";
    $password = md5(123);
    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];
    $city = "Montreal";

    if($latitude && $longitude){
        $sql = "insert into users (full_name, password, latitude, longitude, city) values('$full_name', '$password', $latitude, $longitude, '$city')";

        $result = mysqli_query($conn, $sql);
        if($result){                                                                                            //success message
            $msg = "<div class='alert alert-success alert-dismissible fade show' role='alert'>                  
                        <strong>Inserted!</strong> Record inserted successfully.
                        <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                            <span aria-hidden='true'>&times;</span>
                        </button>
                    </div>";
        }else{                                                                                                  //error message
            $msg = "<div class='alert alert-danger alert-dismissible fade show' role='alert'>                   
                        <strong>Not Inserted!</strong> Record does not inserted, please try again later.
                        <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                            <span aria-hidden='true'>&times;</span>
                        </button>
                    </div>";
        }
    }else{                                                                                                      //warning
        $msg = "<div class='alert alert-warning alert-dismissible fade show' role='alert'>                      
                        <strong>Oops!</strong>  Something went wrong.
                        <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                            <span aria-hidden='true'>&times;</span>
                        </button>
                    </div>";
    }
}
?>