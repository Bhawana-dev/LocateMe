<?php
    include "submit.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=<device-width>, initial-scale=1.0">
    <title>LocateMe</title>
    <link rel="icon" href="icon/location1.png">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container">
        <button  type="button" class="btn btn-primary" onclick="getLocation()">Locate Me</button><br/><br/>

        <form action="#" method="post">
            <table cellpadding="10px">
                <tr>
                    <td>Longitude:</td>
                    <td><input type="text" id="latitude" class="form-control" name="latitude" /></td>
                </tr>
                <tr>
                    <td>Latitude:</td>
                    <td><input type="text" id="longitude" class="form-control" name="longitude" /></td>
                </tr>
                <tr>
                    <td>City:</td>
                    <td><input type="text" id="city" class="form-control" name="city" /></td>
                </tr>
                <tr>
                    <td colspan="2"><button type="submit" class="btn btn-success" name="submit">Submit</button></td>
                </tr>
            </table>
        </form><br/>

        <label id="message"><?php if(isset($msg)){ echo $msg; } ?></label>
    </div>

    <script src="js/script.js"></script>
    <script async defer src="http://maps.google.com/maps/api/js?key=AIzaSyD_7wUs5zFrT2AaKlo20DLnTJ3vUk5e8Ag&callback=initMap"></script>
</body>
</html>