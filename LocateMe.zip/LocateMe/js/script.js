var latitudeTextField = document.getElementById("latitude");
var longitudeTextBox = document.getElementById("longitude");
var city = document.getElementById("city");

var message = document.getElementById("message");

function getLocation() {                                                    //Getting my device's coordinates
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } else {
        message.innerHTML = "Geolocation is not supported by this browser.";
    }
}

function showPosition(position) {                                           //showing coordinates
    var latitude = position.coords.latitude;
    var longitude = position.coords.longitude;

    latitudeTextField.value = latitude;
    longitudeTextBox.value = longitude;
    displayLocation(latitude,longitude);
}

function displayLocation(latitude,longitude){                               //accessing city
    var geocoder;
    var count, country, state;
    geocoder = new google.maps.Geocoder();
    var latlng = new google.maps.LatLng(latitude, longitude);

    geocoder.geocode(
        {'latLng': latlng},
        function(results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                if (results[0]) {
                    var add= results[0].formatted_address ;
                    var  value=add.split(",");

                    count=value.length;
                    country=value[count-1];
                    state=value[count-2];
                    city=value[count-3];
                    city.value = city;
                }
                else  {
                    message.innerHTML = "address not found";
                }
            }
            else {
                message.innerHTML = "Geocoder failed due to: " + status;
            }
        }
    );
}